#include "Lexer.hpp"
#include "Logger.hpp"
#include "FileHandler.hpp"
#include "CodeGenerator.hpp"
#include "Parser.hpp"
#include "JIT.hpp"

#include <cstring>

int main(int argc, char* argv[]) {
  try {
    std::cout << "---------------------------------------------------------" << std::endl;
    std::cout << "Lasa Simplified Imperative Language (LaSIL) COMPILER v0.1" << std::endl;
    std::cout << "                  AUTHOR: RACHIT KAKKAR                  " << std::endl;
    std::cout << "---------------------------------------------------------\n" << std::endl;

    if (argc < 2) {
      DecafLogger::Logger::logMessage(DecafLogger::LogType::ERROR, "Please provide a valid LaSIL file.");
    }

    std::string filePath = argv[1];
    std::string content = DecafIO::readFileToString(filePath);
    DecafLogger::Logger::setFile(content);

    DecafScanning::Lexer lexer(content);
    std::vector<DecafScanning::Token> tokens(lexer.tokenize());
    DecafLogger::Logger::displayTokenList(tokens); // Display the tokens
    std::cout << std::endl;

    DecafParsing::Parser parser(tokens);
    std::unique_ptr<DecafParsing::AST::Function> AST = parser.parse();
    DecafLogger::Logger::displayASTExpr(*AST->body);
    std::cout << std::endl;
    
    DecafJIT::JIT::initJIT();
    DecafCodeGen::CodeGenerator::initOptimizations();
    if (auto *IR = AST->codegen()) {
      IR->print(llvm::errs());
      fprintf(stderr, "\n");
    }

    auto RT = DecafJIT::JIT::JIT_->getMainJITDylib().createResourceTracker();
    auto TSM = llvm::orc::ThreadSafeModule(std::move(DecafCodeGen::CodeGenerator::module_), std::move(DecafCodeGen::CodeGenerator::context));
    DecafJIT::JIT::exitOnError(DecafJIT::JIT::JIT_->addModule(std::move(TSM), RT));
    DecafCodeGen::CodeGenerator::initOptimizations();
    auto exprSymbol = DecafJIT::JIT::exitOnError(DecafJIT::JIT::JIT_->lookup("foo"));
    assert(exprSymbol && "Function not found");
    // Get the symbol's address and cast it to the right type (takes no
    // arguments, returns a double) so we can call it as a native function.
    double (*FP)() = (double (*)())(intptr_t)exprSymbol.getAddress();
    fprintf(stderr, "Evaluated to %f\n\n", FP());

    // Delete the anonymous expression module from the JIT.
    DecafJIT::JIT::exitOnError(RT->remove());
  
    std::exit(0);
  } catch (const std::exception& e) {
    std::cerr << e.what() << std::endl;
  }
  return 0;
}