#ifndef JIT_H
#define JIT_H

#include "KaleidoscopeJIT.hpp"
#include "AST.hpp"

namespace DecafJIT {

class JIT {
public:
  static std::unique_ptr<llvm::orc::KaleidoscopeJIT> JIT_;  
  static llvm::ExitOnError exitOnError;
  static void initJIT();
};

}

#endif