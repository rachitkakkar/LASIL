#include "Lexer.hpp"
#include "Logger.hpp"
#include "FileHandler.hpp"
#include "Parser.hpp"

#include <cstring>

int main(int argc, char* argv[]) {
  try {
    std::cout << "---------------------------------------------------------" << std::endl;
    std::cout << "Lasa Simplified Imperative Language (LaSIL) COMPILER v0.1" << std::endl;
    std::cout << "                  AUTHOR: RACHIT KAKKAR" << std::endl;
    std::cout << "---------------------------------------------------------\n" << std::endl;

    if (argc < 2) {
      DecafLogger::logMessage(DecafLogger::LogType::ERROR, "Please provide a valid LaSIL file.");
    }

    std::string filePath = argv[1];
    std::string content = DecafIO::readFileToString(filePath);

    DecafScanning::Lexer lexer(content);
    std::vector<DecafScanning::Token> tokens(lexer.tokenize());

    DecafParsing::Parser parser(tokens);
    std::unique_ptr<DecafParsing::AST::Function> AST = parser.parse();

    if (argc >= 3) {
      if (std::strcmp(argv[2], "-d") == 0) {
        DecafLogger::displayTokenList(tokens); // Display the tokens
        DecafLogger::displayASTExpr(*AST->body);
      }
    }
  
    std::exit(0);
  } catch (const std::exception& e) {
    std::cerr << e.what() << std::endl;
  }
  return 0;
}