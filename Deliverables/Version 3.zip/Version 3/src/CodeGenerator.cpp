#include "CodeGenerator.hpp"
#include "AST.hpp"
#include "Lexer.hpp"

using namespace DecafCodeGen;
using namespace DecafScanning;

CodeGenerator::CodeGenerator() {
  // Open a new context and module.
  context = std::make_unique<llvm::LLVMContext>();
  module_ = std::make_unique<llvm::Module>("JIT", *context);

  // Create a new builder for the module.
  builder = std::make_unique<llvm::IRBuilder<>>(*context);
}

namespace DecafParsing {

namespace AST {

llvm::Value *NumberExpr::codegen() {
  return llvm::ConstantFP::get(*CodeGenerator::context, llvm::APFloat(value));
}

llvm::Value *VariableExpr::codegen() {
  // Look this variable up in the function.
  llvm::Value *V = CodeGenerator::namedValues[name];
  // if (!V)
  //   LogErrorV("Unknown variable name");
  return V;
}

llvm::Value *BinaryExpr::codegen() {
  llvm::Value *L = LHS->codegen();
  llvm::Value *R = RHS->codegen();
  if (!L || !R)
    return nullptr;

  switch (op.type) {
    case TokenType::PLUS:
      return CodeGenerator::builder->CreateFAdd(L, R, "addtmp");
    case TokenType::MINUS:
      return CodeGenerator::builder->CreateFSub(L, R, "subtmp");
    case TokenType::TIMES:
      return CodeGenerator::builder->CreateFMul(L, R, "multmp");
    case TokenType::LESS_THAN:
      L = CodeGenerator::builder->CreateFCmpULT(L, R, "cmptmp");
      // Convert bool 0/1 to double 0.0 or 1.0
      return CodeGenerator::builder->CreateUIToFP(L, llvm::Type::getDoubleTy(*CodeGenerator::context),
                                  "booltmp");
    // default:
    //   return LogErrorV("invalid binary operator");
  }

  return nullptr; // To-do fix switch default
}

llvm::Value *CallExpr::codegen() {
  // Look up the name in the global module table.
  llvm::Function *calleeF = CodeGenerator::module_->getFunction(callee);
  // if (!calleeF)
  //   return LogErrorV("Unknown function referenced");

  // // If argument mismatch error.
  // if (calleeF->arg_size() != Args.size())
  //   return LogErrorV("Incorrect # arguments passed");

  std::vector<llvm::Value *> argsV;
  for (unsigned i = 0, e = args.size(); i != e; ++i) {
    argsV.push_back(args[i]->codegen());
    if (!argsV.back())
      return nullptr;
  }

  return CodeGenerator::builder->CreateCall(calleeF, argsV, "calltmp");
}

}

}