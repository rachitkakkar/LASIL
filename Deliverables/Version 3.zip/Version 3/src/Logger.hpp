#ifndef LOGGER_H
#define LOGGER_H

// // Forward declaration to avoid circular imports
// namespace DecafScanning {
//   struct Token;
// }
#include "Logger.hpp"
#include "AST.hpp"

#include <iostream>
#include <vector>
#include <string>

namespace DecafLogger {

// To-Do: Fix for default Apple Terminal and Windows
#define ERROR_ESCAPE_SEQUENCE "\e[1;37;41m Error: \e[m"
#define WARNING_ESCAPE_SEQUENCE "\e[1;37;44m Warning: \e[m"
#define DEBUG_ESCAPE_SEQUENCE "\e[1;37;45m Debug Info: \e[m"

enum class LogType {
  DEBUG_INFO,
  ERROR,
  WARNING
};

void logMessage(LogType type, const std::string& msg);
void logMessage(LogType type, const std::string& msg, const std::string& fileText, std::size_t position);
void displayTokenList(const std::vector<DecafScanning::Token>& tokens);
void displayToken(const DecafScanning::Token token);
void displayASTExpr(int level, DecafParsing::AST::Expr& expr);
void displayASTExpr(DecafParsing::AST::Expr& expr);

// class Logger {
// public:
//   explicit Logger(std::string fileText);
//   explicit Logger();

//   static void logMessage(LogType type, const std::string& msg);
//   static void logMessage(LogType type, const std::string& msg, const std::string& fileText, std::size_t position);
//   static void displayTokenList(const std::vector<DecafScanning::Token>& tokens);

// private:
//   static std::string m_fileText;
//   static std::vector<std::string> m_lines;
// };

}

#endif