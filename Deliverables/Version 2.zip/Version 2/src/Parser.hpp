#ifndef PARSER_H
#define PARSER_H

#include "Lexer.hpp"
#include "Logger.hpp"

#include <memory>
#include <map>
#include <utility>

namespace DecafParsing {

namespace AST {

struct Expr {
public:
  virtual ~Expr() = default;
};

struct Prototype {
  public:
    Prototype(const std::string &name, std::vector<std::string> args)
      : name(name), args(std::move(args)) {}

    const std::string &getName() const { return name; }
  private:
    std::string name;
    std::vector<std::string> args;
};

struct Function {
public:
  Function(std::unique_ptr<Prototype> proto,
           std::unique_ptr<Expr> body)
    : proto(std::move(proto)), body(std::move(body)) {}
private:
  std::unique_ptr<Prototype> proto;
  std::unique_ptr<Expr> body;
};

struct NumberExpr : public Expr {
public:
  NumberExpr(double value) : value(value) {}
private:
  double value;
};

struct VariableExpr : public Expr {
public:
  VariableExpr(const std::string &name) : name(name) {}
private:
  std::string name;
};

struct BinaryExpr : public Expr {
public:
  BinaryExpr(DecafScanning::Token op, std::unique_ptr<Expr> LHS,
                std::unique_ptr<Expr> RHS)
    : op(op), LHS(std::move(LHS)), RHS(std::move(RHS)) {}
private:
  DecafScanning::Token op;
  std::unique_ptr<Expr> LHS, RHS;
};

struct CallExpr : public Expr {
public:
  CallExpr(const std::string &callee,
              std::vector<std::unique_ptr<Expr>> args)
    : callee(callee), args(std::move(args)) {}
private:
  std::string callee;
  std::vector<std::unique_ptr<Expr>> args;
};

}

class Parser {
public:
  explicit Parser(std::vector<DecafScanning::Token> tokens);

  std::unique_ptr<AST::Expr> numberExpr();
  std::unique_ptr<AST::Expr> groupingExpr();
  std::unique_ptr<AST::Expr> identifierExpr();
  std::unique_ptr<AST::Expr> parseBinaryExpr(int exprPrec, std::unique_ptr<AST::Expr> LHS);
  std::unique_ptr<AST::Prototype> parsePrototype();
  std::unique_ptr<AST::Function> parseFuncDefinition();
  std::unique_ptr<AST::Expr> parsePrimaryExpr();
  std::unique_ptr<AST::Expr> parseExpr();
  std::unique_ptr<AST::Function> parse();
  DecafScanning::Token peek();

private:
  std::vector<DecafScanning::Token> m_tokens;
  std::map<DecafScanning::TokenType, int> m_binopPrecedence;
  int m_index = 0;

  // DecafScanning::Token peek();
  DecafScanning::Token consume();
};

}

#endif