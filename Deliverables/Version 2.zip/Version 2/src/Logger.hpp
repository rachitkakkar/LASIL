#ifndef LOGGER_H
#define LOGGER_H

#include <iostream>
#include <vector>
#include <string>
namespace DecafScanning {
  struct Token;
} using namespace DecafScanning;


namespace DecafLogger {

// To-Do: Fix for default Apple Terminal and Windows
#define ERROR_ESCAPE_SEQUENCE "\e[1;37;41m Error: \e[m"
#define WARNING_ESCAPE_SEQUENCE "\e[1;37;44m Warning: \e[m"
#define DEBUG_ESCAPE_SEQUENCE "\e[1;37;45m Debug Info: \e[m"

enum class LogType {
  DEBUG_INFO,
  ERROR,
  WARNING
};

void logMessage(LogType type, const std::string& msg);
void logMessage(LogType type, const std::string& msg, const std::string& fileText, std::size_t position);
void displayTokenList(const std::vector<DecafScanning::Token>& tokens);

// class Logger {
// public:
//   explicit Logger(std::string fileText);

//   void logMessage(LogType type, const std::string& msg);
//   void logMessage(LogType type, const std::string& msg, const std::string& fileText, std::size_t position);
//   void displayTokenList(const std::vector<DecafScanning::Token>& tokens);

// private:
//   std::string m_fileText;
//   std::vector<std::string> m_lines;
// };

}

#endif