#include "JIT.hpp"

using namespace DecafJIT;

llvm::ExitOnError JIT::exitOnError;
std::unique_ptr<llvm::orc::KaleidoscopeJIT> JIT::JIT_;

void JIT::initJIT() {
  llvm::InitializeNativeTarget();
  llvm::InitializeNativeTargetAsmPrinter();
  llvm::InitializeNativeTargetAsmParser();

  JIT::JIT_ = exitOnError(llvm::orc::KaleidoscopeJIT::Create());
}