#include "Parser.hpp"

namespace DecafParsing {

Parser::Parser(std::vector<DecafScanning::Token> tokens) : m_tokens(tokens) {
  // 1 is lowest precedence.
  m_binopPrecedence[DecafScanning::TokenType::TIMES] = 4;
  m_binopPrecedence[DecafScanning::TokenType::DIVIDE] = 4;
  m_binopPrecedence[DecafScanning::TokenType::PLUS] = 3;
  m_binopPrecedence[DecafScanning::TokenType::MINUS] = 3;
  m_binopPrecedence[DecafScanning::TokenType::LESS_THAN] = 2;
  m_binopPrecedence[DecafScanning::TokenType::GREATER_THAN] = 2;
  m_binopPrecedence[DecafScanning::TokenType::LESS_THAN_EQUAL] = 2;
  m_binopPrecedence[DecafScanning::TokenType::GREATER_THAN_EQUAL] = 2;
  m_binopPrecedence[DecafScanning::TokenType::EQUAL_EQUAL] = 1;
}

int Parser::getTokPrecedence() {
  if (m_binopPrecedence.count(peek().type) > 0)
    return m_binopPrecedence[peek().type];
  else 
    return -1;
}

DecafScanning::Token Parser::peek() {
  return m_tokens.at(m_index);
}

DecafScanning::Token Parser::consume() {
  return m_tokens.at(m_index++);
}

std::unique_ptr<AST::Expr> Parser::numberExpr() {
  if (peek().type == DecafScanning::TokenType::NUMBER) {
    auto result = std::make_unique<AST::NumberExpr>(std::stof(*peek().value));
    consume();
    return result;
  }
  
  return nullptr; // Todo: Throw error
}

std::unique_ptr<AST::Expr> Parser::groupingExpr() {
  if (peek().type == DecafScanning::TokenType::OPEN_PAREN) {
    consume();
    auto expr = parseExpr();
    if (!expr)
      return nullptr;
    if (peek().type == DecafScanning::TokenType::CLOSE_PAREN) {
      consume();
      return expr;
    }
  }
  
  return nullptr; // Todo: Throw error
}

std::unique_ptr<AST::Expr> Parser::identifierExpr() {
  if (peek().type == DecafScanning::TokenType::IDENTIFIER) {
    std::string name = *peek().value;
    consume();

    if (peek().type != DecafScanning::TokenType::OPEN_PAREN) // Simple variable reference
      return std::make_unique<AST::VariableExpr>(name);
    
    // Function call
    consume();
    std::vector<std::unique_ptr<AST::Expr>> args;
    while (true) {
      if (auto arg = parseExpr()) { // Parse arguments
        args.push_back(std::move(arg));
      }
      else {
        std::cout << "Failed to parse arg! arggg" << std::endl;
        return nullptr; // Todo: Throw error
      }

      if (peek().type == DecafScanning::TokenType::CLOSE_PAREN) // End of function call
        break;

      if (peek().type != DecafScanning::TokenType::COMMA) {
        std::cout << "Expected ')' or ',' in argument list" << std::endl;
        return nullptr; // Todo: Throw an error
      }
      consume();
    }
    consume(); // Consume ')'
    return std::make_unique<AST::CallExpr>(name, std::move(args));
  }

  return nullptr; // Todo: Throw error
}

std::unique_ptr<AST::Expr> Parser::parseBinaryExpr(int exprPrec, std::unique_ptr<AST::Expr> LHS) {
  while (true) {
    int tokPrec = getTokPrecedence();

    // If this is a binop that binds at least as tightly as the current binop,
    // Consume it, otherwise we are done.
    if (tokPrec < exprPrec) {
      // Not binary
      return LHS;
    }

    // Ok, we know this must be a binary value at this point
    DecafScanning::Token binOp = peek();
    consume();

    // Parse the primary expression after the binary operator.
    auto RHS = parsePrimaryExpr();
    if (!RHS) {
      std::cout << "no right hand side???" << std::endl; // To-do: Throw error
      return nullptr;
    }
    
    // If BinOp binds less tightly with RHS than the operator after RHS, let
    // the pending operator take RHS as its LHS
    int nextPrec = getTokPrecedence();
    if (tokPrec < nextPrec) {
      RHS = parseBinaryExpr(tokPrec + 1, std::move(RHS));
      if (!RHS) {
        return nullptr;
      }
    }

    // Merge LHS/RHS for complete binary expression
    LHS = std::make_unique<AST::BinaryExpr>(binOp, std::move(LHS), std::move(RHS));
  }
}

std::unique_ptr<AST::Prototype> Parser::parsePrototype() {
  if (peek().type != DecafScanning::TokenType::IDENTIFIER)
    return nullptr; // Todo: Throw Error
  // Get function name
  std::string fnName = *peek().value;
  consume();

  if (peek().type != DecafScanning::TokenType::OPEN_PAREN)
    return nullptr; // Todo: Throw error
  consume();

  // Read the list of argument names.
  std::vector<std::string> argNames;
  while (peek().type == DecafScanning::TokenType::IDENTIFIER || peek().type == DecafScanning::TokenType::COMMA) {
    if (peek().type == DecafScanning::TokenType::IDENTIFIER) {
      argNames.push_back(*peek().value);
    }
    consume();
  }

  if (peek().type != DecafScanning::TokenType::CLOSE_PAREN)
    return nullptr; // Todo: Throw an error
  consume();

  return std::make_unique<AST::Prototype>(fnName, std::move(argNames));
}

std::unique_ptr<AST::Function> Parser::parseFuncDefinition() {
  if (peek().type == DecafScanning::TokenType::DEF) {
    consume();
    auto proto = parsePrototype(); // Parse function declaration
    if (!proto) return nullptr;

    if (peek().type != DecafScanning::TokenType::OPEN_CURLY) {
      std::cout << "{ expected after function declaration!" << std::endl;
      return nullptr;
    }

    consume();

    auto expr = parseExpr(); // Parse function body
    if (peek().type != DecafScanning::TokenType::CLOSE_CURLY) {
      std::cout << "} expected after function definition!" << std::endl;
      return nullptr;
    }
    consume();

    if (expr) {
      return std::make_unique<AST::Function>(std::move(proto), std::move(expr));
    }

    return nullptr;
  }

  return nullptr; // Todo: Throw an error
}

std::unique_ptr<AST::Expr> Parser::parsePrimaryExpr() {
  // Parse basic, not bin-op expressions
  switch (peek().type) {
    default:
      return nullptr; // Todo: Throw an error
    case DecafScanning::TokenType::IDENTIFIER:
      return identifierExpr();
    case DecafScanning::TokenType::NUMBER:
      return numberExpr();
    case DecafScanning::TokenType::OPEN_PAREN:
      return groupingExpr();
  }
}

std::unique_ptr<AST::Expr> Parser::parseExpr() {
  // Parse any expression (including both the primary ones and bin-ops)
  auto LHS = parsePrimaryExpr();

  if (!LHS)
    return nullptr;
  
  auto expr = parseBinaryExpr(0, std::move(LHS));
  return expr;
}

std::unique_ptr<AST::Function> Parser::parse() {
  // Parse program consiting of functions or (To-do) top level declarations
  switch (peek().type) {
    default:
      return nullptr; // Todo: Throw an error
    case DecafScanning::TokenType::DEF:
      return parseFuncDefinition();
  }
}

}